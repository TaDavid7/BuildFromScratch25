#operations
#filtering, aggregations, group by